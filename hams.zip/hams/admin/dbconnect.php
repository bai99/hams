<?php
mysql_connect("localhost","root","")or die("Server problem");
mysql_select_db("hamsone")or die("database problem");
?>