<?php
session_start();

unset($_SESSION['add_name']);
header('location:index.php');



?>