-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2017 at 10:16 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hamsone`
--

-- --------------------------------------------------------

--
-- Table structure for table `ambulance`
--

CREATE TABLE `ambulance` (
  `am_id` int(11) NOT NULL,
  `am_total` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `am_book`
--

CREATE TABLE `am_book` (
  `ambook_id` int(11) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `uphone` varchar(20) NOT NULL,
  `uemail` varchar(100) NOT NULL,
  `totbookam` int(11) NOT NULL DEFAULT '1',
  `ambulancetype` varchar(100) NOT NULL,
  `extras` varchar(100) NOT NULL,
  `pickup_time` datetime NOT NULL,
  `pickup_place` varchar(300) NOT NULL,
  `dropoff_place` varchar(300) NOT NULL,
  `comments` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `am_book`
--

INSERT INTO `am_book` (`ambook_id`, `uname`, `hospital_id`, `uphone`, `uemail`, `totbookam`, `ambulancetype`, `extras`, `pickup_time`, `pickup_place`, `dropoff_place`, `comments`) VALUES
(1, 'rajib', 0, '345345', 'rajibrsmita@gmail.com', 0, '', '', '0000-00-00 00:00:00', '', '', ''),
(2, 'rajib', 0, '345345', 'rajibrsmita@gmail.com', 0, '', '', '0000-00-00 00:00:00', '', '', ''),
(3, 'rajib', 0, '345345', 'rajibrsmita@gmail.com', 0, '', '', '0000-00-00 00:00:00', '', '', ''),
(4, 'rajib', 0, '345345', 'rajibrsmita@gmail.com', 0, 'van', 'baby', '2017-07-17 12:00:00', '', 'zcxc', 'zxczc'),
(5, 'rajib', 0, '345345', 'rajibrsmita@gmail.com', 0, 'van', 'baby', '2017-07-17 12:00:00', '', 'zcxc', 'zxczc'),
(6, 'ss', 0, 'ss', 'rajibrsmita@gmail.com', 0, 'van', 'baby', '2017-07-17 02:02:00', '', 'ss', 'sss'),
(7, 'rajib', 0, '333', 'rajibrsmita@gmail.com', 0, 'car', 'baby', '2017-07-17 03:03:00', '', 'asdd', 'asd'),
(8, 'rajib', 0, '333', 'rajibrsmita@gmail.com', 0, 'car', 'baby', '2017-07-17 03:03:00', '', 'asdd', 'asd'),
(9, 'a', 0, '1', 'rajibrsmita@gmail.com', 0, 'van', 'baby', '2017-07-18 03:03:00', '', 'ss', '22'),
(10, 'rajib', 0, '345345', 'rajibrsmita@gmail.com', 0, 'car', 'baby', '2017-07-17 01:01:00', '', 'sfds', 'sfdsfsf'),
(11, '', 0, '', '', 0, '', '', '0000-00-00 00:00:00', '', '', ''),
(12, '', 0, '', '', 0, '', '', '0000-00-00 00:00:00', '', '', ''),
(13, '', 0, '', '', 0, '', '', '0000-00-00 00:00:00', '', '', ''),
(14, '', 0, '', '', 0, '', '', '0000-00-00 00:00:00', '', '', ''),
(15, 'rajib', 0, 'ss', 'rajibrsmita@gmail.com', 0, 'on', 'baby', '2017-08-01 00:00:00', '', 'sdfs', 'sfdsdf'),
(16, 'g', 0, 'd', 'rajibrsmita@gmail.com', 0, 'on', 'baby', '2017-08-10 00:00:00', '', 'd', 'd'),
(17, 'd', 0, 'd', 'rajibrsmita@gmail.com', 1, 'on', 'baby', '2017-08-02 00:00:00', '', 'sds', 'sds'),
(18, '', 0, '', '', 1, '', '', '0000-00-00 00:00:00', '', '', ''),
(19, '', 0, '', '', 1, '', '', '0000-00-00 00:00:00', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(300) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`city_id`, `city_name`, `status`) VALUES
(1, 'Dhaka', 1),
(2, 'Chittagong', 1),
(3, 'Rajshahi', 1),
(4, 'Khulna', 1),
(5, 'Rangpur', 1),
(6, 'Dinajpur', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doctor_id` int(11) NOT NULL,
  `doctor_name` varchar(300) NOT NULL,
  `specialty` varchar(255) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `chamber_location` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doctor_id`, `doctor_name`, `specialty`, `hospital_id`, `chamber_location`) VALUES
(1, 'Dr. K. M. Nazmul Islam Joy', 'Medicine', 5, 'Lab Aid Diagnostic Uttara (unit 2), Sector -13,H -41, Garib e newaz road , Uttara, Dhaka'),
(2, 'Dr. Faisal Ahmed', '0', 6, 'Dr. Faisal Ahmed'),
(3, 'Dr. Mohammad Enamul Haque', '0', 7, 'Delta Health Care Mirpur Ltd., Main Br., Mirpur, Dhaka'),
(4, 'Asst. Prof. Dr. Sarmistha Biswas', '0', 8, 'South East Model Hospital, Main Branch, Jurain, Dhaka'),
(5, 'Dr. Chandra Shakhar Bala', '0', 9, 'Health and Hope Hospital, Main Branch, Panthapath, Dhaka'),
(6, 'Dr. Pravashish Adhikari', '0', 10, 'Sima General Hospital & Diagnostic Center, Main Branch, Savar, Dhaka'),
(7, 'Dr. MD. Ahmed Monzurul Aziz', '0', 11, 'Digilab Medical Services Ltd., Pallabi Br., Pallabi, Dhaka'),
(8, 'Dr. Mehraj Islam', '0', 12, 'Sheba Ultrasono Clinic (Room no- 8), Green Super Market (1st Floor) , Green Road, Dhaka'),
(9, 'Dr. Md. Mamunur Rashid', '0', 13, 'Savar, Dhaka'),
(10, 'Dr. Swapan Kumer Sur', '0', 14, 'Mahiya Pharmacy. H- 66,Rd- 2/A (Opposite to Matbor Tower), Zigatola, Dhaka'),
(11, 'Prof. Dr. Mohammad Zahir Uddin', '0', 15, 'Ibn Sina Diagnostic & Imaging Center, House 48, Road 9/A, Dhanmondi, Dhaka'),
(12, 'Dr. Md. Faruk Rahman Mazumder', 'Medicine', 16, 'Al-Helal Specialized Hospital Ltd., Main Branch, Mirpur, Dhaka'),
(13, 'Professor (Dr.) Mohammad Safiuddin', 'Cardiology', 17, 'Popular Medical College Hospital Consultation Center Road No-02, Dhanmondi,, Dhaka'),
(14, 'Professor (Dr.) Md. Fakhrul Islam', 'Cardiology /Heart Specialist', 6, '"LABAID CARDIAC HOSPITAL\r\nHouse # 1, Road # 4, Dhanmondi\r\nDhaka-1205, Bangladesh."'),
(15, 'Dr. H. I. Lutfor Rahman Khan', 'Cardiology /Heart Specialist', 1, '"Comfort Diagnostic Centre & Comfort Nursing Home\r\nComfort Tower, 167/B, Green Road, Dhanmondi, Dhaka – 1205"'),
(16, 'Professor Dr. Md. Afjalur Rahman', 'Cardiology /Heart Specialist', 18, '"LABAID CARDIAC HOSPITAL\r\nHouse # 1, Road # 4, Dhanmondi\r\nDhaka-1205, Bangladesh."'),
(17, 'Professor Dr. Abduz Zaher', 'Cardiology /Heart Specialist', 5, '"LABAID CARDIAC HOSPITAL\r\nHouse # 1, Road # 4, Dhanmondi\r\nDhaka-1205, Bangladesh."'),
(18, 'Professor Hasina Banoo', 'Cardiology /Heart Specialist', 18, '"Labaid Specialized Hospital – Gulshan Branch\r\nHouse # 13/A, Road # 35, Gulshan-2, Dhaka-1212.\r\nPhone: +880-2-8835981-4, 8858943, 8835966"'),
(19, 'Professor Dr. K.M.H.S. Sirajul Haque', 'Cardiology /Heart Specialist', 19, '"LABAID CARDIAC HOSPITAL\r\nHouse # 1, Road # 4, Dhanmondi\r\nDhaka-1205, Bangladesh."'),
(20, 'Professor Dr. M. Jalaluddin', 'Cardiology /Heart Specialist', 5, '"LABAID CARDIAC HOSPITAL\r\nHouse # 1, Road # 4, Dhanmondi\r\nDhaka-1205, Bangladesh."'),
(21, 'Professor Dr. M. Nazrul Islam', 'Cardiology /Heart Specialist', 17, '"Popular Diagnostic Centre Ltd – Dhanmondi Branch\r\nHouse # 16, Road # 2, Dhanmondi R/A, Dhaka – 1205\r\nPhone: +880-2-9669480, 9661491-3, Mobile – 01553341060-1, 01553341063"'),
(22, 'Dr. Md. Abdullah Khan', 'Dentist', 20, '"Metropolitan Dental Location: Sel Green Center, 30, Green Road, Dhaka - 1205, Bangladesh\r\nPhone: +880-2-8625317"'),
(23, 'Dr. M. A. Sikder', 'Dentist', 21, '"Smile Specialised Dental & Research Center\r\nLocation: 12 Gaznabi Road, College Gate, Mohammadpur, Dhaka - 1207, Bangladesh\r\nPhone: +880 1914553088"'),
(24, 'Professor Dr. Md. Shamsul Alam', 'Dentist', 17, '"Green Life Hospital Limited\r\nLocation: 32 Green Road ( Bir Uttom K. M Shafiullah Sarak ) , Dhanmondi, Dhaka - 1205\r\nPhone: +880-2-9612345-54, 9615412, 8628820-1"'),
(25, 'Professor Dr. Khandaker Abdul Azim', 'Dentist', 22, '"Ibn Sina Dental Center\r\nLocation: House # 47, Road # 9/A, Satmasjid Road, Dhanmondi, Dhaka - 1209, Bangladesh\r\nPhone: +880-2-91296625-6, 9128835-7 ( Chamber )"'),
(26, 'Dr. Mohammed Shafi Ullah', 'Dentist', 23, '"Islami Bank Central Hospital\r\nLocation: 30, Anjuman Mafidul Islam Road, Kakrail , Dhaka-1000\r\nPhone: +880-2-9355801-2, 9360331-2"'),
(27, 'Dr. Nurul Amin', 'Dentist', 23, '"Smile Specialised Dental & Research Center\r\nLocation: 12 Gaznabi Road, College Gate, Mohammadpur, Dhaka - 1207, Bangladesh\r\nPhone: +880 1914553088"'),
(28, 'Dr. Salahuddin (Swapon)', 'Dentist', 17, '"Sudeen Dental Care\r\nLocation: 20, Green Road, Rangs Taz tower, Dhanmondi, Dhaka - 1205\r\nPhone: +880 1711958143"'),
(29, 'Dr. Mohammad Shafi Ullah', 'Dentist', 24, '"Smile Specialised Dental & Research Center\r\nLocation: 12 Gaznabi Road, College Gate, Mohammadpur, Dhaka - 1207, Bangladesh\r\nPhone: +880 1914553088"'),
(30, 'Dr. Syed T. Ahsan Ratan', 'Dentist', 25, '"Ratan''s Dental (Panthapath)\r\nLocation: 150, Green Road, Dhaka - 1205\r\nPhone: +880-2-9111090, 01711823382"'),
(31, 'Dr. Clopa Pina Podder', 'Dentist', 26, '"Smile Specialised Dental & Research Center\r\nLocation: 12 Gaznabi Road, College Gate, Mohammadpur, Dhaka - 1207, Bangladesh\r\nPhone: +880 1914553088"'),
(32, 'Dr. Mohammad Saiful Alam Talukder', 'Dentist', 27, '"Tooth Planet\r\nVisiting Hours: 4:00 PM to 10:00 PM\r\nLocation: House: 91/1, Road: 11A, Dhanmondi, Dhaka, Bangladesh.\r\nPhone: +88-0119-3368478\r\nemail: info@toothplanet.org"'),
(33, 'Dr. A.S.M. Zakariya', 'Dermatology', 17, '"Central Hospital Ltd. Anex-2,\r\n18, Green Road, Dhanmondi,Dhaka\r\nPhone : 9660015-19, 9121592, 01819238575"'),
(34, 'Dr. A.T.M. Asaduzzaman', 'Dermatology', 17, '"Japan Bangladesh Friendship Hospital\r\nH-55, R-3/A, Dhanmondi, Satmasjid Road, Dhaka\r\nPhone : 9672277, 9664028, 9664029,\r\n9676161, 9674535, 9675674,1712138285\r\nFax : 88-02-882649"'),
(35, 'Dr. Abdul Quaium Chowdhury', 'Dermatology', 28, '"Panpacific Hospital\r\nTraining & Research Institute Ltd.\r\n24 Outer Circuler Road (Near Pirjongi Majar), Motijheel,Dhaka-1217"'),
(36, 'Dr. Abida Sultana', 'Dermatology', 17, '"S. Rahman Hospital Ltd\r\nSaeed Grand Center\r\nBeigement, Plot-89, R-28, S-7, Uttara, Dhaka-1230\r\nPhone : 8951928, 8950244, 01718710344, 01712691732"'),
(37, 'Dr. Md. Abdur Rahim Miah', 'Dermatology', 17, '"Japan Bangladesh Friendship Hospital\r\nH-55, R-3/A, Dhanmondi, Satmasjid Road, Dhaka\r\nPhone: +880-2-9672277, 9676161, 9664028, 9664029"'),
(38, 'Dr. Iqbal Murshed Kabir', 'Gastroenterology', 29, '"Apollo Hospitals Dhaka\r\nLocation: Plot # 81, Block # E, Basudhara R/A, Dhaka - 1229\r\nPhone: +880-2-8401661, 8845242, Cell: +880 1841276556, Hotline: 10678"'),
(39, 'Professor Dr. Anowar Kabir', 'Gastroenterology', 29, '"Apollo Hospitals Dhaka\r\nLocation: Plot # 81, Block # E, Basudhara R/A, Dhaka - 1229\r\nPhone: +880-2-8401661, 8845242, Cell: +880 1841276556, Hotline: 10678"'),
(40, 'Professor Dr. Md. Anisur Rahman', 'Gastroenterology', 30, '"Liver Foundation of Bangladesh\r\n150, Green Road, Panthapath, Dhaka - 1205\r\nPhone: +880 2 9146537, 06662606260"'),
(41, 'Professor Dr. Md. Anisur Rahman', 'Gastroenterology', 30, '"Popular Diagnostic Centre Ltd - Dhanmondi Branch\r\nLocation: House # 16, Road # 2, Dhanmondi R/A, Dhaka - 1205\r\nPhone: +880-2-9669480, 9661491-3, Mobile - 01553341060-1, 01553341063"'),
(42, 'Professor Dr. A.S.M.A Raihan', 'Gastroenterology', 17, '"AFMC - Armed Forces Medical College\r\nLocation: House # 16, Road # 2, Dhanmondi R/A, Dhaka - 1205\r\nPhone: +880-2-9669480, 9661491-3, Mobile - 01553341060-1, 01553341063"'),
(43, 'Professor Dr. Fazlul Hoque', 'Gastroenterology', 1, '"Northern International Medical College & Hospital\r\nLocation: House # 84, Road # 8/A ( New ), Dhanmondi, Dhaka - 1209, Bangladesh\r\nPhone: +880-2-8156914, 8156839, 9133505, 9111381,\r\nCell: +880 1674058435, +880 1715153935 ( Chamber )"'),
(44, 'Professor Dr. Sheikh Nesaruddin Ahmed', 'Medicin\r\n\r\n\r\n\r\n', 5, '"LABAID CARDIAC HOSPITAL\r\nHouse # 1, Road # 4, Dhanmondi\r\nDhaka-1205. Phone: + 880-2-8610793 - 8, 9670210 - 3, 8631177"'),
(45, 'Professor Dr. Syed Atiqul Haq', 'Medicin', 17, '"Green Life Hospital Ltd. Green Road, Dhaka: \r\nLocation: 32 Bir Uttam K M Shafiullah Sarak (Green Road ), Dhanmondi, Dhaka- 1205\r\nPhone: +880-2-9612345, 8628820-1"'),
(46, 'Professor Dr. H A M Nazmul Ahsan', 'Medicine', 1, '"Popular Diagnostic Centre Ltd - Dhanmondi Branch\r\nLocation: House # 16, Road # 2, Dhanmondi R/A, Dhaka - 1205\r\nPhone: +880-2-9669480, 9661491-3"'),
(47, 'Professor Dr. Ferdous Ara J. Janan', 'Medicine', 17, '"Popular Diagnostic Centre Ltd. - Shyamoli Branch\r\nLocation: House # ( 22/7 ) 29, Bir Uttam A.N.M Nuruzzaman Sorak,\r\n(Babor road) Block# b, Mohammadpur, Dhaka-1207, Bangladesh\r\nPhone: +880-2- 9111911( Chamber )"'),
(48, 'Dr. Abu Jafar Chowdhury', 'Orthopedic', 17, '"LABAID CARDIAC HOSPITAL\r\nHouse # 1, Road # 4, Dhanmondi\r\nDhaka-1205. Phone: + 880-2-8610793 - 8, 9670210 - 3, 8631177"'),
(49, 'Professor Dr. Kh. Abdul Awal', 'Orthopedic', 31, '"Green Life Hospital Ltd. Green Road, Dhaka: \r\nLocation: 32 Bir Uttam K M Shafiullah Sarak (Green Road ), Dhanmondi, Dhaka- 1205"'),
(50, 'Professor Dr. M. Hafizur Rahman', 'Orthopedic', 32, '"Delta Medical College & Hospital\r\nLocation: 26/2, Principal Abul Kashem Road, Mirpur-1, Dhaka- 1212, Bangladesh\r\nPhone: +880-2-8017151-52, 8031378-79"'),
(51, 'Professor M. K. I. Qayyum Chowdhury', 'Orthopedic', 33, '"Dhaka Central Hospital\r\nLocation: Dhanmondi, Road no # 5, Green Road, Dhaka, Bangladesh\r\nPhone: +880-2-9660015, 8624515"');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `hospital_id` int(11) NOT NULL,
  `hospital_name` varchar(500) NOT NULL,
  `hospital_cat` varchar(500) NOT NULL,
  `hospital_location` varchar(500) NOT NULL,
  `city_id` int(11) NOT NULL,
  `am_tot` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hospital_id`, `hospital_name`, `hospital_cat`, `hospital_location`, `city_id`, `am_tot`, `status`) VALUES
(1, 'Dhaka medical', 'General Hospital / Clinic', '', 1, 10, 1),
(2, 'Khanpur general hospital', 'genaral', '', 2, 20, 1),
(3, 'Chittagong Medical', '', '', 2, 30, 1),
(4, 'Rajshahi general hospital', '', '', 3, 50, 1),
(5, 'Labaid Hospital', 'Diagnostic', 'Lab Aid Diagnostic Uttara (unit 2), Sector -13,H -41, Garib e newaz road , Uttara, Dhaka', 1, 10, 1),
(6, 'Medicare Diagnostic & Hospital', 'Diagnostic/Clinic', 'Medicare Diagnostic & Hospital Kamrangirchar Diabetic Center, Main Branch, Kamrangirchar, Dhaka', 1, 15, 1),
(7, 'Delta Health Care', 'Clinic', 'Delta Health Care Mirpur Ltd., Main Br., Mirpur, Dhaka', 1, 20, 1),
(8, 'South East Model Hospital', 'Diagnostic Center', 'South East Model Hospital, Main Branch, Jurain, Dhaka', 1, 25, 1),
(9, 'Health and Hope Hospital', 'Diagnostic/Clinic', 'Health and Hope Hospital, Main Branch, Panthapath, Dhaka', 1, 30, 1),
(10, 'Sima General Hospital & Diagnostic Center', 'Hospital & Diagnostic Center', 'Sima General Hospital & Diagnostic Center, Main Branch, Savar, Dhaka', 1, 20, 1),
(11, 'Digilab Medical Services Ltd', 'Medical', 'Digilab Medical Services Ltd., Pallabi Br., Pallabi, Dhaka', 1, 10, 1),
(12, 'Sheba Ultrasound Clinic ', 'Clinic ', 'Green Super Market (1st Floor) , Green Road, Dhaka', 1, 15, 1),
(13, 'Lab Zone (Pvt.) Ltd.', 'Private Hospital', 'Savar, Dhaka', 1, 10, 1),
(14, 'Mahiya Pharmacy', 'Clinic', 'H- 66,Rd- 2/A (Opposite to Matbor Tower), Zigatola, Dhaka', 1, 20, 1),
(15, 'Ibn Sina Diagnostic & Imaging Center', 'Diagnostic & Imaging Center', 'House 48, Road 9/A, Dhanmondi, Dhaka', 1, 30, 1),
(16, 'Al-Helal Specialized Hospital Ltd', 'Diagnostic/Clinic', 'Al-Helal Specialized Hospital Ltd., Main Branch, Mirpur, Dhaka', 1, 10, 1),
(17, 'Bangabandhu Sheikh Mujib Medical University', 'General Hospital', 'Dhaka 1000, Bangladesh', 1, 30, 1),
(20, 'Metropolitan Dental', 'Dental', '"Sel Green Center, 30, Green Road, Dhaka - 1205, Bangladesh\r\nPhone: +880-2-8625317"', 1, 25, 1),
(21, 'Smile Specialized Dental & Research Center', 'Dental Hospital', '"Smile Specialised Dental & Research Center\r\nLocation: 12 Gaznabi Road, College Gate, Mohammadpur, Dhaka - 1207, Bangladesh\r\nPhone: +880 1914553088"', 1, 30, 1),
(22, 'Ibn Sina Dental Center', 'Dental Hospital', '"Ibn Sina Dental Center\r\nLocation: House # 47, Road # 9/A, Satmasjid Road, Dhanmondi, Dhaka - 1209, Bangladesh\r\nPhone: +880-2-91296625-6, 9128835-7 ( Chamber )"', 1, 25, 1),
(23, 'Sapora Dental College & Hospital', 'Dental Hospital', 'Plot no 24. Sector 8, Dhaka 1230, Bangladesh', 1, 20, 1),
(24, 'Ad-Din Medical College & Hospital', 'Medical College & Hospital', '2 Bara Maghbazar, Outer Circular Rd, Dhaka 1217', 1, 200, 1),
(25, 'Ratan''s Dental', 'Dental Hospital', '"Ratan''s Dental (Panthapath)\r\nLocation: 150, Green Road, Dhaka - 1205\r\nPhone: +880-2-9111090, 01711823382"', 1, 20, 1),
(26, 'Bangladesh Institute of Medical and Dental Technology (BIMDT)', 'Dental Hospital', 'House No. 12, Mirpur Rd, Dhaka 1207', 1, 25, 1),
(27, 'Tooth Planet', 'Dental Hospital', '"Tooth Planet\r\nVisiting Hours: 4:00 PM to 10:00 PM\r\nLocation: House: 91/1, Road: 11A, Dhanmondi, Dhaka, Bangladesh.\r\nPhone: +88-0119-3368478\r\nemail: info@toothplanet.org"', 1, 20, 1),
(28, 'Panpacific Hospital', '', 'Dhalka', 1, 15, 1),
(29, 'Apollo Hospital Dhaka', 'General Hospital', 'Location: Plot # 81, Block # E, Basudhara R/A, Dhaka - 1229', 1, 30, 1),
(30, 'BIRDEM', 'Hospital', '122,Kazi Nazrul Islam Avenue,Shahbagh,Dhaka 1000', 1, 30, 1),
(31, 'National Orthopedic Hospital', 'Orthopedic Hospital', 'Syed Mahbub Morshed Ave, Dhaka 1207', 1, 20, 1),
(32, 'Delta Medical College & Hospital', 'Medical College & Hospital', '26/2, Principal Abul Kashem Road, Mirpur-1, Dhaka- 1212', 1, 25, 1),
(33, 'Dhaka Central Hospital', 'General Hospital', '"Dhaka Central Hospital\r\nLocation: Dhanmondi, Road no # 5, Green Road, Dhaka, Bangladesh\r\nPhone: +880-2-9660015, 8624515"', 1, 20, 1);

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE `reg` (
  `reg_id` int(11) NOT NULL,
  `reg_user` varchar(300) NOT NULL,
  `reg_pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`reg_id`, `reg_user`, `reg_pass`) VALUES
(1, 'b', 'b'),
(2, 'b', 'b');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `am_book`
--
ALTER TABLE `am_book`
  ADD PRIMARY KEY (`ambook_id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`hospital_id`);

--
-- Indexes for table `reg`
--
ALTER TABLE `reg`
  ADD PRIMARY KEY (`reg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `am_book`
--
ALTER TABLE `am_book`
  MODIFY `ambook_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doctor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `hospital_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `reg`
--
ALTER TABLE `reg`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
